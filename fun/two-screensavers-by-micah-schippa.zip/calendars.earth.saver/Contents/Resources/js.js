// Set your clock

// Get year

var d = new Date();
var year = d.getFullYear();
console.log(year);

// Set inputs

var time1 = document.querySelector(".time-1");
var time2 = document.querySelector(".time-2");
var time3 = document.querySelector(".time-3");
var time4 = document.querySelector(".time-4");
var time5 = document.querySelector(".time-5");
var time6 = document.querySelector(".time-6");
var time7 = document.querySelector(".time-7");
var time8 = document.querySelector(".time-8");
var time9 = document.querySelector(".time-9");
var time10 = document.querySelector(".time-10");
var time11 = document.querySelector(".time-11");
var time12 = document.querySelector(".time-12");
var time13 = document.querySelector(".time-13");
var time14 = document.querySelector(".time-14");
var time15 = document.querySelector(".time-15");
var time16 = document.querySelector(".time-16");
var time17 = document.querySelector(".time-17");
var time18 = document.querySelector(".time-18");
var time19 = document.querySelector(".time-19");
var time20 = document.querySelector(".time-20");
var time21 = document.querySelector(".time-21");
var time22 = document.querySelector(".time-22");
var time23 = document.querySelector(".time-23");
var time24 = document.querySelector(".time-24");
var time25 = document.querySelector(".time-25");
var time26 = document.querySelector(".time-26");
var time27 = document.querySelector(".time-27");
var time28 = document.querySelector(".time-28");
var time29 = document.querySelector(".time-29");
var time30 = document.querySelector(".time-30");
var time31 = document.querySelector(".time-31");

// Tools

function setYearRange(year1, year2) {
	return year1 + "–" + year2;
}

// Ab urbe condita

if (year >= -752) {
	var abUrbe = year + 753;
} else {
	var abUrbe = "N/A";
}
 
time1.innerHTML = abUrbe;

// Assyrian

time2.innerHTML = year + 4750;

// Baha’i

if (year >= 1844) {
	bahai = setYearRange(year - 1844, year - 1843);
} else {
	var bahai = "N/A";
}

time3.innerHTML = bahai;

// Balinese saka

if (year - 76 > 0) {
	balinesesaka = setYearRange(year - 79, year - 78);
} else {
	var balinesesaka = "N/A";
}

time4.innerHTML = balinesesaka;

// Bengali

time5.innerHTML = year - 593;

// Berber

time6.innerHTML = year + 950;

// Buddhist

var buddhistDate = new Intl.DateTimeFormat('th-TH-u-nu-thai', {era:'long'}).format(year);
time7.innerHTML = year + 544 + " (" + buddhistDate + ")";

// Burmese

time8.innerHTML = year - 638;

// Byzantine

time9.innerHTML = setYearRange(year + 5508, year + 5509);

// Chinese

var cheavenlyStems = [
	['甲', 'Wood'],			// 1
	['乙', 'Wood'],			// 2
	['丙', 'Fire'],			// 3
	['丁', 'Fire'],			// 4
	['戊', 'Earth'],			// 5
	['己', 'Earth'],			// 6
	['庚', 'Metal'],			// 7
	['辛', 'Metal'],			// 8
	['壬', 'Water'],			// 9
	['癸', 'Water']			// 10
];

var cearthlyBranches = [
	['子', 'Rat'],					// 1
	['丑', 'Ox'],					// 2
	['寅', 'Tiger'],					// 3
	['卯', 'Rabbit'],				// 4
	['辰', 'Dragon'],				// 5
	['巳', 'Snake'],					// 6
	['午', 'Horse'],					// 7
	['未', 'Goat'],					// 8
	['申', 'Monkey'],				// 9
	['酉', 'Rooster'],				// 10
	['戌', 'Dog'],					// 11
	['亥', 'Pig']					// 12
];

var csexagenaryYear1 = ( year - 4 ) % 60;
var csexagenaryYear2 = ( year - 3 ) % 60;
var cheavenlyNum1 = (csexagenaryYear1 - 1) % 10;
var cheavenlyNum2 = (csexagenaryYear2 - 1) % 10;
var cearthlyNum1 = (csexagenaryYear1 - 1) % 12;
var cearthlyNum2 = (csexagenaryYear2 - 1) % 12;

var cheavenlyTable1 = cheavenlyStems[cheavenlyNum1];
var cheavenlyTable2 = cheavenlyStems[cheavenlyNum2];
var cearthlyTable1 = cearthlyBranches[cearthlyNum1];
var cearthlyTable2 = cearthlyBranches[cearthlyNum2];

var cyear1 = year + 2696;
var cyear2 = year + 2697;
var cyear1Alt = cyear1 - 60;
var cyear2Alt = cyear2 - 60;

var cyear1 = cyear1.toString();
var cyear2 = cyear2.toString();
var cyear1Alt = cyear1Alt.toString();
var cyear2Alt = cyear2Alt.toString();
			
time10.innerHTML = cheavenlyTable1[0] + cearthlyTable1[0] + "年 " + "(" + cheavenlyTable1[1] + "&nbsp;" + cearthlyTable1[1] + "), " + cyear1 + " or " + cyear1Alt + " to " + cheavenlyTable2[0] + cearthlyTable2[0] + "年 " + "(" + cheavenlyTable2[1] + "&nbsp;" + cearthlyTable2[1] + "), " + cyear2 + " or " + cyear2Alt;

// Coptic

time11.innerHTML = setYearRange(year - 284, year - 283);

// Discordian

time12.innerHTML = year + 1166;

// Ethiopian

time13.innerHTML = setYearRange(year - 8, year - 7);

// Hebrew

time14.innerHTML = setYearRange(year + 3760, year + 3761);

// Hindu Vikram Samvat

time15.innerHTML = setYearRange(year + 56, year + 57);

// Hindu Shaka Samvat
	
if (year >= 78) {
	time16.innerHTML = setYearRange(year - 79, year - 78);
} else {
	time16.innerHTML = "N/A";
}

// Hindu Kali Yuga

time17.innerHTML = setYearRange(year + 3100, year + 3101);

// Holocene

time18.innerHTML = year + 10000;

// Igbo
	
if (year >= 1000) {
	time19.innerHTML = setYearRange(year - 1000, year - 999);
} else {
	time19.innerHTML = "N/A";
}

// Iranian

if (year - 621 > 0) {
	time20.innerHTML = setYearRange(year - 622, year - 621);
} else {
	time20.innerHTML = setYearRange(622 - year, 621 - year);
}

// Islamic

var islamicYear = new Intl.DateTimeFormat('ar-TN-u-ca-islamic', {day: 'numeric', month: 'long',weekday: 'long',year : 'numeric'}).format(year);
	
var islamicMult = 1.030684;
var islamicSub = 621.5643;
if (year - 621 > 0) {
	islamicyear1 = Math.floor(islamicMult * (year - islamicSub));
	islamicyear2 = Math.floor(islamicMult * (year - islamicSub + 1));
	time21.innerHTML = setYearRange(islamicyear1, islamicyear2) + " / " + islamicYear;
} else {
	islamicyear1 = -islamicMult * (year - islamicSub);
	islamicyear2 = -islamicMult * (year - islamicSub + 1);
	time21.innerHTML = setYearRange(islamicyear1, islamicyear2) + " / " + islamicYear;
}

// Japanese

time22.innerHTML = "Heisei 31 / Reiwa 1 (令和元年)";
var japaneseYear = new Intl.DateTimeFormat('ja-JP-u-ca-japanese', {era:'long'}).format(year);
time22.innerHTML = japaneseYear;

// Javanese

var javaneseMult = 1.030684;
var javaneseSub = 124.9;
if (year - 124 > 0) {
	javaneseyear1 = Math.floor(javaneseMult * (year - javaneseSub));
	javaneseyear2 = Math.floor(javaneseMult * (year - javaneseSub + 1));
	time23.innerHTML = setYearRange(javaneseyear1, javaneseyear2);
} else {
	javaneseyear1 = -javaneseMult * (year - javaneseSub);
	javaneseyear2 = -javaneseMult * (year - javaneseSub + 1);
	time23.innerHTML = setYearRange(javaneseyear1, javaneseyear2);
}

// Juche

if (year >= 1910) {
	if (year > 1911) {
		time24.innerHTML = year - 1911;
	}
}

// Julian

if (year >= -45 && year < 1582) {
	time25.innerHTML = year;
} else if (year >= 1582) {
	var diff = Math.floor(year/100-2) - Math.floor(year/400);
	if (year % 100 == 0 && year % 400 != 0) {
		time25.innerHTML = "Gregorian minus " + diff-1 + " or" + diff + " days";
	} else {
		time25.innerHTML = "Gregorian minus " + diff + " days";
	}
}

// Korean

time26.innerHTML = year + 2333;

// Minguo

if (year > 1949) {
	minguoYear = year - 1911;
	time27.innerHTML = "ROC " + minguoYear + " or " + "民國" + minguoYear + "年";
} else if (year > 1911) {
	minguoYear = year - 1911;
	time27.innerHTML = "Republic of China (1912–1949) " + minguoYear + " or " + "民國" + minguoYear + "年";
} else {
	minguoYear = 1911 - year + 1;
	time27.innerHTML = minguoYear + " before Republic of China (1912–1949)" + " or " + "民國" + minguoYear + "年";
}

// Nanakshahi

time28.innerHTML = year - 1468;

// Thai solar

if (year >= 1941) {
	time29.innerHTML = year + 543;
} else {
	time29.innerHTML = setYearRange(year + 542, year + 543);
}

// Tibetan

var heavenlyStems = [
	['阳木', 'male Wood'],			// 1
	['阴木', 'female Wood'],			// 2
	['阳火', 'male Fire'],			// 3
	['阴火', 'female Fire'],			// 4
	['阳土', 'male Earth'],			// 5
	['阴土', 'female Earth'],		// 6
	['阳金', 'male Iron'],			// 7
	['阴金', 'female Iron'],			// 8
	['阳水', 'male Water'],			// 9
	['阴水', 'female Water']			// 10
];

var earthlyBranches = [
	['鼠', 'Rat'],					// 1
	['牛', 'Ox'],					// 2
	['虎', 'Tiger'],					// 3
	['兔', 'Rabbit'],				// 4
	['龙', 'Dragon'],				// 5
	['蛇', 'Snake'],					// 6
	['马', 'Horse'],					// 7
	['羊', 'Goat'],					// 8
	['猴', 'Monkey'],				// 9
	['鸡', 'Rooster'],				// 10
	['狗', 'Dog'],					// 11
	['猪', 'Pig']					// 12
];

var sexagenaryYear1 = ( year - 4 ) % 60;
var sexagenaryYear2 = ( year - 3 ) % 60;
var heavenlyNum1 = (sexagenaryYear1 - 1) % 10;
var heavenlyNum2 = (sexagenaryYear2 - 1) % 10;
var earthlyNum1 = (sexagenaryYear1 - 1) % 12;
var earthlyNum2 = (sexagenaryYear2 - 1) % 12;

var heavenlyTable1 = heavenlyStems[heavenlyNum1];
var heavenlyTable2 = heavenlyStems[heavenlyNum2];
var earthlyTable1 = earthlyBranches[earthlyNum1];
var earthlyTable2 = earthlyBranches[earthlyNum2];

var tyear1 = year + 126;
var tyear2 = year + 127;
var tyear1Alt1 = tyear1 - 381;
var tyear1Alt2 = tyear1 - 1153;
var tyear2Alt1 = tyear2 - 381;
var tyear2Alt2 = tyear2 - 1153;

var tyear1 = tyear1.toString();
var tyear2 = tyear2.toString();
var tyear1Alt1 = tyear1Alt1.toString();
var tyear1Alt2 = tyear1Alt2.toString();
var tyear2Alt1 = tyear2Alt1.toString();
var tyear2Alt2 = tyear2Alt2.toString();

time30.innerHTML = heavenlyTable1[0] + earthlyTable1[0] + "年 " + tyear1 + " or " + tyear1Alt1 + " or " + tyear1Alt2 + " to " + heavenlyTable2[0] + earthlyTable2[0] + "年 " + tyear2 + " or " + tyear2Alt1 + " or " + tyear2Alt2;


// time30.innerHTML = heavenlyTable1[0] + earthlyTable1[0] + "年 " + "(" + heavenlyTable1[1] + "-" + earthlyTable1[1] + ")" + ", " + tyear1 + " or " + tyear1Alt1 + " or " + tyear1Alt2 + " to " + heavenlyTable2[0] + earthlyTable2[0] + "年 " + "(" + heavenlyTable2[1] + "-" + earthlyTable2[1] + ")" + ", " + tyear2 + " or " + tyear2Alt1 + " or " + tyear2Alt2;

// Unix

var t=setInterval(updateUnix,1000);

function updateUnix() {
	var unix = Math.round(+new Date()/1000);
	var time31 = document.querySelector(".time-31");
 	time31.innerHTML = unix;
}

// Time's up
