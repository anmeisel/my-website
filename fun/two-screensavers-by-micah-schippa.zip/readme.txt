to install a screensaver: double-click the .saver file
it will open system preferences, and ask if you want to install it
if the newly installed screensaver does not immediately appear in system preferences: please close and re-open system preferences: now it should be there.

if you need any support please don't hesitate to contact us on content@left.gallery