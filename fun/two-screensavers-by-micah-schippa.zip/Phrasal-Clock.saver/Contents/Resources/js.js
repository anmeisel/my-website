var mtext = ["Dialogue","Construct","Exhibition","Lattice","Constellation","Disease","Origins","Symbols","Healing","Texts","Psalms","Tablets","Apsis","Spheres","Index","Archive","Fiction","Cipher","Solstice","Vigil","Morning Prayers","Midday Prayers","Evening Prayers","Parting","Hexagon","Heron","Imp","Aphelion","Perihelion","Lunar Year","Star Cluster","Spring Tide","Wandering Star","Eclipse","Hermit","Clockmaker","Chimes","Pendulum","Joining","Ceramicist","Scripture","Precession","Measurements","Torchlight","Flooding","Heliosphere","Left Eye","Right Eye","Open Mouth","Closed Mouth","Bog","Larch","Honeysuckle","Entwined","Forgotten","Reverse","Fallen Nest","Scimitar","Oryx","Bison"];
var htext = ["Figures","Fifths","Resonance","Worry","Ornaments","Hymns","the Cicada","Transience","Liturgy","Cobwebs","Columns","Complexity","Cinder","Bronze","Exile","Loss","Acceptance","Diagrams","Parables","Apology","Incandescence","the Aphid","Fractals","Mortality"];
var stext = ["Cedar","Honey","Copper","Lapis","Cerulean","Bud","Coral","Sea life","Spruce","Amber","Celadon","Climate","Basalt","Solids","Aril","Ochre","Alabaster","Sienna","Ivory","Folk","Silicon","Ebony","Sentience","Sand","Liquid","Resin","Chalk","Soot","Crimson","Sepal","Pluot","Cobalt","Blood","Phosphorescence","Disappearing","Clay","Tide","Continuity","Crystalline","Mineral","Porcelain","Animal","Snow","Cider","Slate","Opal","Obsidian","Bone","Ash","Transparency","Translation","Shadow","Shore","Seaward","Beryl","Juniper","Onyx","Tiger","Brass","Pearl"];
var daytext = ["the Living","Parallels","Clocks","Exchange","the Forge","Soot","the Dead"];
var monthtext = ["Ancestors","Insects","Clay-making","Ink-making"];

var result = document.getElementById("result");
var shadow = document.getElementById("shadow");

function getMonthText(monthIndex) { // monthIndex=[0 .. 11]
    switch (monthIndex) {
        case 0:
        case 1:
        case 2:
            return monthtext[3]
        case 3:
        case 4:
        case 5:
            return monthtext[2];
        case 6:
        case 7:
        case 8:
            return monthtext[1];
        case 9:
        case 10:
        case 11:
            return monthtext[0];
            
    }
}

const steps = 1
let prevMinute = null

function updateText() {
    var d = new Date();
    var m = d.getMinutes();
    var h = d.getHours();
    var s = d.getSeconds();
    var day = d.getDay();
    var month = d.getMonth();
    
    const text = stext[s]
        + ': the '
        + mtext[m]
        + ', in the hour of '
        + htext[h]
        + '; day of '
        + daytext[day]
        + ', '
        +  'in the season of ' + getMonthText(month) + '.'

    shadow.innerHTML = text
    
    result.innerHTML = text;
    const width = (shadow.offsetWidth / steps << 0) * steps
    if (prevMinute === null || m !== prevMinute) {
        result.style.width = (width + 180) + 'px';
        prevMinute = m
    }
    setTimeout(updateText, 1000)
}

updateText()
